public class T2 {
    public static void main(String[] args) {
        double m = 15;
        double n = 1;

        if (Math.abs(m - 10) > Math.abs(n - 10)) {
            System.out.println("N is closer");
        } else {
            System.out.println("M is closer");
        }
    }
}
